# MuK Preview Text

Extendes the Preview Dialog to support text files. It supports most of the common text file extensions.