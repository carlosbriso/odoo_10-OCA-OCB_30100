# MuK Preview Video

Extendes the Preview Dialog to support videos. Currently the following video extensions are supported:

* WebM (*.webm, video/webm)
* Ogg Theora Vorbis (*.ogg, video/ogg)
* MP4 (*.mp4, video/mp4)