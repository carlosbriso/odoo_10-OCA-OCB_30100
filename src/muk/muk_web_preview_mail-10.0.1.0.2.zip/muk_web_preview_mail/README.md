# MuK Preview Mail

Extendes the Preview Dialog to support mails. Currently the following mail extensions are supported:

* Microsoft Outlook Express Mail Message (*.eml, message/rfc822)