# MuK Web Client Notification

Adds a notification channel to the web client. By sending a message to this channel, a global notification is send.