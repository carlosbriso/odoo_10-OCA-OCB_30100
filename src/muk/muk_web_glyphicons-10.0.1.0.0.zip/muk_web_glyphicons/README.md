# Bootstrap Glyphicons Support

Odoo does not natively support the Glyphicons from Bootstrap although 
it uses the framework. This module enables the Bootstrap Glyphicons.

The Glyphicons from Font Awesome which are used by Odoo will still
be available.