# MuK Scroll Up Button

Adds a button to the bottom of the page to jump back up to the top of the page.