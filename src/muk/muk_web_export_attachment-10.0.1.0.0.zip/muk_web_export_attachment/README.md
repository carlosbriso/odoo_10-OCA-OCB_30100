# MuK Export Attachment

Adds a button to the Attachment Sidebar to export the content directly in the browser.