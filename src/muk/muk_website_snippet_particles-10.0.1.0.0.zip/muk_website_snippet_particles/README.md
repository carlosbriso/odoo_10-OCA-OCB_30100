# MuK Particle Snippet

Adds a snippet to the Odoo Website. The snippet uses particlesJS
to give a variety of customization options. 