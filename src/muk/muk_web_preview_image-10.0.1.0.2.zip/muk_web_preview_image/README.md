# MuK Preview Image

Extendes the Preview Dialog to support images. Currently the following image extensions are supported:

* CIS-Cod-Dateien (*.cod, image/cis-cod)
* CMU-Raster-Dateien (*.ras, image/cmu-raster)
* FIF-Dateien (*.fif, image/fif)
* GIF-Dateien (*.gif, image/gif)
* IEF-Dateien (*.ief, image/ief)
* JPEG-Dateien (*.jpeg *.jpg *.jpe, image/jpeg)
* PNG-Dateien (*.png, image/png)
* TIFF-Dateien (*.tiff *.tif, image/tiff)
* Vasa-Dateien (*.mcf, image/vasa)
* Bitmap-Dateien (WAP) (*.wbmp, image/vnd.wap.wbmp)
* Freehand-Dateien (*.fh4 *.fh5 *.fhc, image/x-freehand)
* Icon-Dateien (*.ico, image/x-icon)
* PBM Anymap Dateien (*.pnm, image/x-portable-anymap)
* PBM Bitmap Dateien (*.pbm, image/x-portable-bitmap)
* PBM Graymap Dateien (*.pgm, image/x-portable-graymap)
* PBM Pixmap Dateien (*.ppm, image/x-portable-pixmap)
* RGB-Dateien (*.rgb, image/x-rgb)
* X-Windows Dump (*.xwd, image/x-windowdump)
* XBM-Dateien (*.xbm, image/x-xbitmap)
* XPM-Dateien (*.xpm, image/x-xpixmap)