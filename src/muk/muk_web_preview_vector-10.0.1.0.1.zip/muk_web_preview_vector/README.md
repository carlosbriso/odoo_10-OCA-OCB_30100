# MuK Preview Vector

Extendes the Preview Dialog to support vector graphics.
Currently the following vector graphic extensions are supported:

* Scalable Vector Graphics (*.svg, image/svg+xml)