# Transparent Navigation Menu

Adds a option to the website customize menu to trigger the transparent navigation menu.