# MuK Preview CSV

Extendes the Preview Dialog to support csv files. Currently the following extensions are supported:

* CSV (*.csv, text/csv)