# MuK Gradient Option

Extends the Odoo Website Customize Background Color
menu to give a selection of gradient backgrounds.