# MuK Preview Audio

Extendes the Preview Dialog to support audio. Currently the following audio extensions are supported:

* Wav (*.wav, audio/wav)
* Ogg Theora Vorbis (*.ogg, audio/ogg)
* MP3 (*.mp3, audio/mpeg)