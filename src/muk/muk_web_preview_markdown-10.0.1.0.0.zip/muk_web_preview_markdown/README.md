# MuK Preview Markdown

Extendes the Preview Dialog to support Markdown files.